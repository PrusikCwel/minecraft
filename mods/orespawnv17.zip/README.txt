Hi!

Welcome to OreSpawn!

For all the details about everything you'll ever need,
including every crafting recipies, 
and even little tidbits about each mob, plant, and item,
Please visit www.OreSpawn.com

Nothing special here. You shouldn't even be reading this! 
You don't need to do anything. Nothing to extract.
Just drag and drop the entire zip file, as is, into your .minecraft/mods folder.

Thank you for playing our mod!!!



TheyCallMeDanger
